find .. -type f -name "graph.json" -delete


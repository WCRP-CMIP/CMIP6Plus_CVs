

find .. -type f -name "*.bak" -delete
